from .clip2point import CLIP2Point
from .dpa import DPA
from .CLIP2PointCIL import *
from .CLIP2Point import *
from .dgcnn_cls import *
__all__ = ['CLIP2Point', 'DPA']
